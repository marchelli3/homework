from behave import given, when, then
import requests
import json
import math


@given('weather forecast provider url is "https://api.openweathermap.org/data/2.5/weather"')
def step(context):
    context.address = 'https://api.openweathermap.org/data/2.5/weather'
    context.payload = {}


@given('parameter "{key}" is equal to "{value}"')
def step(context, key, value):
    context.payload[key] = value


@when('GET method is called')
def step(context):
    context.r = requests.get('https://api.openweathermap.org/data/2.5/weather', params=context.payload)


@then('response is with status code "{resp_code:d}"')
def step(context, resp_code):
    if context.r.status_code == resp_code:
        print(f"Response code correct")
    else:
        print(f"error received")


@then('response contains property "text" with valid "json" document')
def step(context):
    json.loads(context.r.content.decode('utf-8'))


@then('save temperature in a file')
def step(context):
    context.j = json.loads(context.r.content.decode('utf-8'))
    context.main_print = (context.j['main']['temp'])
    with open("logs.txt", "w") as out_file:
        out_file.write(str(context.main_print))


@then('convert it from kelvin to celsius')
def step(context):
    celsius_main_print = math.fsum([float(context.main_print), -273])
    celsius_main = float("{0:.2f}".format(celsius_main_print))
    with open("logs.txt", "w") as out_file:
        out_file.write(str(celsius_main))
